<?php
session_start();
include_once "php/config.php";
if(!isset($_SESSION['unique_id'])){
    header("location: LoginPage.php");
}
?>
<?php include_once "header.php"; ?>
<html>
<head>
    <link rel="stylesheet" href="css/Template.css">
    <script src="https://kit.fontawesome.com/b17df002ae.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="wrapper">
    <header>
        <?php
        $sql = mysqli_query($conn, "SELECT * FROM users JOIN profiletable ON profiletable.unique_id = users.unique_id JOIN gallerypicturestable 
                                        ON gallerypicturestable.unique_id = users.unique_id WHERE users.unique_id = {$_SESSION['unique_id']}");
        if(mysqli_num_rows($sql) > 0){
            $row = mysqli_fetch_assoc($sql);
        }
        if ($row['Age'] == 0){
            $age = "Age Unset";
        } else {
            $age = $row['Age'];
        }
        ?>
        <div class="header metrics button">
            <a href="Metrics.php" title="User Metrics"> <i class="fa-solid fa-rocket"></i> </a>
        </div>
        <div class="header chat button">
            <a href="users.php" title="Chat"> <i class="fa-solid fa-comments"></i> </a>
        </div>
        <div class="header find button">
            <a href="Find.php" title="Find Someone"> <i class="fa-solid fa-magnifying-glass"></i> </a>
        </div>
        <div class="header logo">
            <a href="index.php">
                <img src="https://raw.githubusercontent.com/calvin224/MatchIt/master/css/images/title.png">
                <img src="https://raw.githubusercontent.com/calvin224/MatchIt/master/css/images/titlealt.png" class="hover">
            </a>
        </div>
        <div class="header notifications">
            <a href="Notifications.php" title="Notifications"> <i class="fa-solid fa-bell"></i> </a>
        </div>
        <div class="header profilepicture">
            <a href="EditProfile.php"> <img src="php/images/<?php echo $row['img']; ?>" alt=""> </a>
        </div>
    </header>

    <div class="container">

        <div class="leftCol">
            <div class="leftColSub">
                <div class="profileImage">
                    <img src="php/images/<?php echo $row['img']; ?>" alt="">
                </div>

                <div class="attributes">
                    <img src="css/images/freshhatch.png" title="New Hatch">
                    <img src="css/images/frosty.png" title="Frosty!">
                    <img src="css/images/inshell.png" title="In Your Shell">
                    <img src="css/images/onfire.png" title="On Fire!">
                </div>

                <div class="nameDiv">
                    <p>
                        <?php echo $row['fname']. " " . $row['lname'] ?>
                    </p>
                    <p>
                        <?php echo $age ?>
                    </p>
                    <p>
                        <?php echo $row['Location'] ?>
                    </p>
                    <p>
                        PHYSICAL DESCRIPTION
                    </p>
                </div>

            </div>
        </div>




        <div class="midCol">
            <div class="midColSub">
                <h1>BIO</h1>
                <div class="midPara">
                    <p>
                        <?php echo $row['Description'] ?>
                    </p>
                </div>
                <div class="midBottom">
                    <div>
                        <h3>Hobbies</h3>
                        <div>
                            <p>Dancing</p>
                            <p>Night Life</p>
                            <p>Music</p>
                        </div>
                        <h3>Interests</h3>
                        <div>
                            <p>Dancing</p>
                            <p>Night Life</p>
                            <p>Music</p>
                        </div>
                        <h3>Characterstics</h3>
                        <div>
                            <p>Dancing</p>
                            <p>Night Life</p>
                            <p>Music</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>






        <div class="rightCol">
            <div class="rightColSub">
                <img
                        class="rightColImages"
                        alt="main_Image"
                        src="php/images/<?php echo $row['GalleryPicture1']; ?>"
                />
                <img
                        class="rightColImages"
                        alt="main_Image"
                        src="php/images/<?php echo $row['GalleryPicture2']; ?>"
                />
                <img
                        class="rightColImages"
                        alt="main_Image"
                        src="php/images/<?php echo $row['GalleryPicture3']; ?>"
                />
            </div>
        </div>

    </div>










</div>

<script src="javascript/users.js"></script>

</body>
</html>
    <footer>
        <div class="footer logo">
            <a href="index.php"> <img src="css/images/logo.png" alt="Logo"> </a>
        </div>
    </footer>
</div>

<script src="javascript/users.js"></script>

</body>
</html>
