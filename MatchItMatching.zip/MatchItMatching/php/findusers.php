<?php
session_start();
include_once "config.php";
$outgoing_id = $_SESSION['unique_id'];
$true = 1;
$sql2 = mysqli_query($conn, "SELECT * FROM users JOIN profiletable ON profiletable.unique_id = users.unique_id WHERE users.unique_id = {$_SESSION['unique_id']}");
$row = mysqli_fetch_assoc($sql2);
$Seeking = mysqli_real_escape_string($conn, $row['Seeking']);
$userPreference = $row['Seeking'];
$preferenceVar = 'male';
switch($userPreference){
    case 'male':
        ;
        break;
}
$sql = "SELECT * from users LEFT JOIN profiletable ON profiletable.unique_id=users.unique_id WHERE Completed = {$true} 
                                                  AND NOT users.unique_id = {$outgoing_id} 
                                                AND Gender = {$userPreference} ORDER BY user_id DESC";

$query = mysqli_query($conn, $sql);
$output = "";
if(mysqli_num_rows($query) == 0){
    $output .= "";
}elseif(mysqli_num_rows($query) > 0){
    include_once "findusertable.php";
}
echo $output;
?>